package com.wf.training.spring.mvc.controller;

import org.springframework.stereotype.Controller;

// container for multiple request handling method

@Controller
public class HomeController {
	
	// Action/Handler methods
	/*
	 * 1. Access modifier : public
	 * 2. Return type : String ( view name )
	 * 3. Name : any
	 * 4. Parameter : depends on req
	 * 5. URL Mapped 
	 */
}
